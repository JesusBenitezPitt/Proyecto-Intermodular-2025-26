from odoo import models, fields, api

class ResUsers(models.Model):
    _inherit = 'res.users'

    sesiones_log_ids = fields.One2many(
        'autenticacion.sesion.log', 
        'usuario_id', 
        string='Historial de Sesiones'
    )
    
    def write(self, values):
        
        res = super(ResUsers, self).write(values)
        
        if 'login_date' in values and values.get('login_date'):
            for user in self:
                self.env['autenticacion.sesion.log'].sudo().create({
                    'usuario_id': user.id,
                    'fecha_sesion': values['login_date'], 
                })
                
        return res