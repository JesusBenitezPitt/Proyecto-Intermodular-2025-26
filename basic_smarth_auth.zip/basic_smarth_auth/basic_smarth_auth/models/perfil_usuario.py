from odoo import models, fields, api

class AutenticacionSesionLog(models.Model):
    _name = 'autenticacion.sesion.log'
    _description = 'Log de Auditoría de Seguridad Inteligente'
    _order = 'fecha_sesion desc'

    # Relación principal: Ahora vinculamos al Partner
    partner_id = fields.Many2one(
        'res.partner', 
        string='Contacto/Sujeto', 
        required=True, 
        ondelete='cascade',
        readonly=True
    )
    
    # CAMPOS RELACIONADOS: Se llenan solos desde res.partner
    x_nombre_usuario = fields.Char(
        related='partner_id.name', 
        string="Nombre del Usuario", 
        store=True,
        readonly=True
    )
    x_correo_electronico = fields.Char(
        related='partner_id.email', 
        string="Email Registrado", 
        store=True,
        readonly=True
    )

    # DATOS DINÁMICOS (Cambian en cada sesión)
    x_ip = fields.Char(string='Dirección IP', readonly=True)
    x_dispositivo = fields.Char(string='Dispositivo', readonly=True)
    x_navegador = fields.Char(string='Navegador', readonly=True)
    x_localizacion = fields.Char(string='Localización Geo', readonly=True)
    
    fecha_sesion = fields.Datetime(
        string='Fecha y Hora de Intento', 
        default=fields.Datetime.now, 
        readonly=True
    )

    x_estado_intento = fields.Selection([
        ('exito', 'Éxito'),
        ('fallo', 'Fallo'),
        ('riesgo', 'Riesgo Alto')
    ], string='Resultado de Validación', default='exito', readonly=True)

    # Gestión de Auditoría
    estado_revision = fields.Selection([
        ('pendiente', 'Pendiente de Revisión'),
        ('revisado', 'Confirmado/Seguro'),
        ('fraudulento', 'Fraude Detectado')
    ], string='Estado de Auditoría', default='pendiente')
    
    notas_admin = fields.Text(string='Observaciones Técnicas')