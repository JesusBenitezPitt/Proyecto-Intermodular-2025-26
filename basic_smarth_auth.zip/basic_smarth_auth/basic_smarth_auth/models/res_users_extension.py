from odoo import models, fields, api
import logging
try:
    from odoo.http import request
except Exception:
    request = None

_logger = logging.getLogger(__name__)

class ResPartner(models.Model):
    _inherit = 'res.partner'

    # Campos de control que definimos en la tabla
    x_nivel_confianza = fields.Selection([
        ('bajo', 'Bajo'),
        ('medio', 'Medio'),
        ('alto', 'Alto')
    ], string="Nivel de Confianza (IA)", default='medio')

    x_limite_intentos = fields.Integer(string="Intentos Fallidos", default=0)
    x_is_blocked = fields.Boolean(string="Bloqueo de Seguridad", default=False)
    x_ultima_conexion = fields.Datetime(string="Última Conexión")
    
    # Relación inversa para ver logs desde el contacto
    x_log_ids = fields.One2many(
        'autenticacion.sesion.log', 
        'partner_id', 
        string="Historial de Accesos"
    )

class ResUsers(models.Model):
    _inherit = 'res.users'

    def _login(self, credential, user_agent_env=None):
        # Ejecutamos el login original de Odoo
        auth_result = super(ResUsers, self)._login(credential, user_agent_env=user_agent_env)

        try:
            if not auth_result:
                return auth_result

            # Obtener el UID del resultado
            if isinstance(auth_result, dict):
                uid = auth_result.get('uid') or auth_result.get('user_id')
            else:
                uid = int(auth_result)

            if not uid:
                return auth_result

            # BUSCAMOS AL USUARIO Y SU PARTNER ASOCIADO
            user = self.sudo().browse(uid)
            partner = user.partner_id

            # Captura de datos del navegador/IP
            ip = request.httprequest.remote_addr if request else '0.0.0.0'
            ua = request.httprequest.user_agent if request else None

            # PREPARAMOS LOS VALORES PARA AutenticacionSesionLog
            vals = {
                'partner_id': partner.id,  # Vinculamos al Partner
                'x_ip': ip,
                'x_dispositivo': ua.platform if ua else 'Desconocido',
                'x_navegador': ua.browser if ua else 'Desconocido',
                'x_estado_intento': 'exito',
                'fecha_sesion': fields.Datetime.now(),
                'estado_revision': 'pendiente',
            }

            # Creamos el log
            self.env['autenticacion.sesion.log'].sudo().create(vals)

            # Actualizamos el estado del Partner (Reset de intentos y última conexión)
            partner.sudo().write({
                'x_limite_intentos': 0,
                'x_ultima_conexion': fields.Datetime.now()
            })

        except Exception:
            _logger.exception("Error registrando log en el Partner para uid=%s", uid)

        return auth_result